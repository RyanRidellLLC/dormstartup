# DormUp
A simple platform to help dorm room founders launch their startups.