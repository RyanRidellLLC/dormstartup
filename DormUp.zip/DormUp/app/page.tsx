// Homepage for your student startup platform

export default function Home() {
  return (
    <main className="min-h-screen bg-white text-gray-900 flex flex-col items-center p-6 space-y-12">
      <header className="text-center max-w-3xl">
        <h1 className="text-4xl font-bold mb-4">Build Big Ideas From Your Dorm Room</h1>
        <p className="text-lg text-gray-700">
          At <span className="font-semibold">DormUp</span>, we’re dedicated to helping dorm-room founders turn ideas into startups. Connect with builders, mentors, investors, and launch to the moon — all in one place.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-5xl">
        <Card title="👥 Join the Community" desc="Connect with student founders, chat in niche forums, and start building your team." action="Join Now" />
        <Card title="🚀 Launch Your Startup" desc="Apply to pitch, meet investors, and get your project funded through our platform." action="Apply as Founder" />
        <Card title="🎓 Mentor the Future" desc="Support young entrepreneurs with your experience and network." action="Apply as Mentor" />
        <Card title="💼 Invest in Talent" desc="Get early access to student-led innovation and pitch days." action="Apply as Investor" />
      </div>

      <section className="text-center max-w-xl space-y-4">
        <h2 className="text-2xl font-semibold">Why We’re Different</h2>
        <p className="text-gray-700">
          Unlike bloated startup platforms, <span className="font-semibold">DormUp</span> is built for simplicity. No noise. Just connection, clarity, and execution — from dorm room to demo day.
        </p>
      </section>

      <footer className="text-sm text-gray-500 mt-16">
        &copy; {new Date().getFullYear()} DormUp. All rights reserved.
      </footer>
    </main>
  );
}

function Card({ title, desc, action }) {
  return (
    <div className="border rounded-2xl shadow-sm p-6 flex flex-col items-start bg-gray-50 hover:bg-white transition">
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600 mb-4">{desc}</p>
      <button className="bg-black text-white px-4 py-2 rounded-full text-sm hover:opacity-90">
        {action}
      </button>
    </div>
  );
}